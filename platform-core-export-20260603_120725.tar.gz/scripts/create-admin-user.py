#!/usr/bin/env python3
"""
Create an admin user directly in the database.

Usage:
    # Interactive mode:
    export DATABASE_URL="postgresql://..."
    python scripts/create-admin-user.py

    # Command-line args:
    python scripts/create-admin-user.py --name admin --email admin@test.com --password MyPass123
"""

import os
import sys
import argparse
from datetime import datetime
from getpass import getpass

from sqlalchemy import create_engine, text
import bcrypt


def hash_password(password: str) -> str:
    """Hash password using bcrypt."""
    password_bytes = password.encode('utf-8')
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    return hashed.decode('utf-8')


def create_admin_user(database_url: str, name: str, email: str, password: str):
    """Create an admin user in the database."""

    # Create database engine
    engine = create_engine(database_url)

    # Hash the password
    hashed_password = hash_password(password)

    # SQL to insert admin user
    insert_sql = text("""
        INSERT INTO users (name, email, password_hash, role, approval_status, created_at)
        VALUES (:name, :email, :password_hash, 'ADMIN', 'APPROVED', :created_at)
        RETURNING id, name, email, role, approval_status;
    """)

    try:
        with engine.connect() as conn:
            # Check if user already exists
            check_sql = text("SELECT id FROM users WHERE name = :name OR email = :email")
            result = conn.execute(check_sql, {"name": name, "email": email})
            if result.fetchone():
                print(f"❌ Error: User with name '{name}' or email '{email}' already exists")
                return False

            # Insert admin user
            result = conn.execute(insert_sql, {
                "name": name,
                "email": email,
                "password_hash": hashed_password,
                "created_at": datetime.utcnow()
            })
            conn.commit()

            user = result.fetchone()
            print("\n✅ Admin user created successfully!")
            print(f"   ID: {user[0]}")
            print(f"   Name: {user[1]}")
            print(f"   Email: {user[2]}")
            print(f"   Role: {user[3]}")
            print(f"   Status: {user[4]}")
            print("\n🔐 You can now login with:")
            print(f"   Email: {email}")
            print(f"   Password: [the password you entered]")
            return True

    except Exception as e:
        print(f"❌ Error creating admin user: {e}")
        return False
    finally:
        engine.dispose()


def main():
    """Main function."""
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Create an admin user in the database")
    parser.add_argument("--name", "-n", help="Admin name")
    parser.add_argument("--email", "-e", help="Admin email")
    parser.add_argument("--password", "-p", help="Admin password")
    args = parser.parse_args()

    print("=" * 60)
    print("Create Admin User")
    print("=" * 60)
    print()

    # Get database URL from environment
    database_url = os.environ.get("DATABASE_URL")
    if not database_url:
        print("❌ Error: DATABASE_URL environment variable not set")
        print()
        print("Set it with:")
        print('  export DATABASE_URL="postgresql://..."')
        print()
        return 1

    # Get user details (from args or prompt)
    if args.name:
        name = args.name
    else:
        print("Enter admin user details:")
        print()
        name = input("Name: ").strip()

    if not name:
        print("❌ Error: Name cannot be empty")
        return 1

    if args.email:
        email = args.email
    else:
        email = input("Email: ").strip()

    if not email:
        print("❌ Error: Email cannot be empty")
        return 1

    if args.password:
        password = args.password
    else:
        password = getpass("Password: ")
        if not password:
            print("❌ Error: Password cannot be empty")
            return 1

        password_confirm = getpass("Confirm password: ")
        if password != password_confirm:
            print("❌ Error: Passwords do not match")
            return 1

    print()
    print(f"Creating admin user '{name}'...")
    print()

    # Create admin user
    success = create_admin_user(database_url, name, email, password)

    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
