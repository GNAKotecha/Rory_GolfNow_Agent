"""Comprehensive error handling for agent execution.

Provides error classification, recovery strategies, and telemetry for tool failures.
Implements MCP-aligned error handling with fast-fail for auth errors and HITL-safe recovery.

Task C2: Enhanced error classification using MCPToolResult structured fields.
"""
from enum import Enum
from typing import Dict, Any, Optional, TYPE_CHECKING
from dataclasses import dataclass, field
import logging
import os
import json
import re

# Type checking import to avoid circular dependency
if TYPE_CHECKING:
    from app.services.mcp_client import MCPToolResult

logger = logging.getLogger(__name__)


# Feature flag for strict terminal behavior (default: True for safety)
STRICT_TOOL_FAILURE_TERMINAL = os.environ.get(
    "STRICT_TOOL_FAILURE_TERMINAL", "true"
).lower() == "true"


class ErrorType(Enum):
    """Types of errors during agent execution."""
    # Retryable errors
    TOOL_FAILURE = "tool_failure"  # Generic/transient tool failure
    TIMEOUT = "timeout"
    RATE_LIMIT = "rate_limit"
    RESOURCE_EXHAUSTED = "resource_exhausted"
    
    # Non-retryable errors (fast-fail)
    AUTH_FAILURE = "auth_failure"  # 401/403 credential issues
    RBAC_DENIED = "rbac_denied"  # Role policy denial (not credential issue)
    VALIDATION_ERROR = "validation_error"  # 400/schema mismatch
    TOOL_NOT_FOUND = "tool_not_found"  # 404 - tool doesn't exist
    CONTRACT_ERROR = "contract_error"  # Tool response doesn't match schema
    CATALOG_STALE = "catalog_stale"  # Catalog expired mid-run
    
    # Workflow errors
    MALFORMED_OUTPUT = "malformed_output"
    LOOP_DETECTED = "loop_detected"
    LOW_CONFIDENCE = "low_confidence"
    MAX_RETRIES_EXHAUSTED = "max_retries_exhausted"


class RetryClassification(Enum):
    """Whether an error is retryable."""
    RETRYABLE = "retryable"
    NON_RETRYABLE = "non_retryable"
    CONDITIONAL = "conditional"  # Depends on retry budget


# HTTP status code to error type mapping
HTTP_ERROR_CLASSIFICATION: Dict[int, ErrorType] = {
    400: ErrorType.VALIDATION_ERROR,
    401: ErrorType.AUTH_FAILURE,
    403: ErrorType.AUTH_FAILURE,
    404: ErrorType.TOOL_NOT_FOUND,
    422: ErrorType.VALIDATION_ERROR,
    429: ErrorType.RATE_LIMIT,
    500: ErrorType.TOOL_FAILURE,
    502: ErrorType.TOOL_FAILURE,
    503: ErrorType.TOOL_FAILURE,
    504: ErrorType.TIMEOUT,
}

# Non-retryable error types (fast-fail immediately)
NON_RETRYABLE_ERRORS = {
    ErrorType.AUTH_FAILURE,
    ErrorType.RBAC_DENIED,
    ErrorType.VALIDATION_ERROR,
    ErrorType.TOOL_NOT_FOUND,
    ErrorType.CONTRACT_ERROR,
    ErrorType.LOOP_DETECTED,
    ErrorType.CATALOG_STALE,
}


@dataclass
class ErrorContext:
    """Context for error decision making."""
    error_type: ErrorType
    step_number: int
    tool_name: Optional[str]
    error_message: str
    retry_count: int
    metadata: Dict[str, Any] = field(default_factory=dict)
    http_status: Optional[int] = None
    attempt_budget: int = 3  # Global retry budget for this tool call


class ErrorRecoveryStrategy(Enum):
    """Recovery strategies for different error types."""
    RETRY = "retry"
    SKIP = "skip"
    FALLBACK = "fallback"
    ABORT = "abort"
    ASK_USER = "ask_user"


@dataclass
class ErrorRecoveryAction:
    """Action to take when recovering from an error."""
    strategy: ErrorRecoveryStrategy
    reason: str
    fallback_tool: Optional[str] = None
    retry_delay_seconds: Optional[float] = None
    remediation_prompt: Optional[str] = None  # For ASK_USER - structured prompt
    terminal: bool = False  # Whether this ends the workflow


@dataclass
class ToolCallTelemetry:
    """Structured telemetry for tool call attempts."""
    tool_name: str
    error_type: Optional[str]
    http_status: Optional[int]
    retryable: bool
    attempt_index: int
    attempt_budget: int
    recovery_strategy: str
    terminal: bool
    duration_ms: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging/tracing."""
        return {
            "tool_name": self.tool_name,
            "error_type": self.error_type,
            "http_status": self.http_status,
            "retryable": self.retryable,
            "attempt_index": self.attempt_index,
            "attempt_budget": self.attempt_budget,
            "recovery_strategy": self.recovery_strategy,
            "terminal": self.terminal,
            "duration_ms": self.duration_ms,
        }


def classify_error_from_http_status(status_code: int) -> ErrorType:
    """
    Classify error type from HTTP status code.
    
    Args:
        status_code: HTTP response status code
        
    Returns:
        Appropriate ErrorType for the status
    """
    return HTTP_ERROR_CLASSIFICATION.get(status_code, ErrorType.TOOL_FAILURE)


def classify_error_from_category(error_category: Optional[str], http_status: Optional[int] = None) -> Optional[ErrorType]:
    """
    Classify error type from structured error category (Task B2).
    
    Args:
        error_category: Structured error category from MCPToolResult
        http_status: Optional HTTP status for fallback
        
    Returns:
        ErrorType if category is recognized, None otherwise
    """
    if not error_category:
        return None
    
    category_mapping = {
        # Task B2: Tool-not-found variants
        "tool_not_found": ErrorType.TOOL_NOT_FOUND,
        "catalog_miss": ErrorType.TOOL_NOT_FOUND,
        
        # Catalog stale - separate terminal error
        "catalog_stale": ErrorType.CATALOG_STALE,
        
        # Server/infrastructure issues (terminal - admin action needed)
        "server_unavailable": ErrorType.RESOURCE_EXHAUSTED,
        "container_unavailable": ErrorType.RESOURCE_EXHAUSTED,
        "docker_unavailable": ErrorType.RESOURCE_EXHAUSTED,
        "connection_refused": ErrorType.RESOURCE_EXHAUSTED,
        "upstream_unavailable": ErrorType.RESOURCE_EXHAUSTED,
        
        # Upstream returned error response (retryable - LLM can try different approach)
        "upstream_error": ErrorType.TOOL_FAILURE,
        
        # RBAC denial (policy, not credentials)
        "rbac_denied": ErrorType.RBAC_DENIED,
        
        # Credential/auth issues
        "auth_failure": ErrorType.AUTH_FAILURE,
        "permission_denied": ErrorType.AUTH_FAILURE,  # Legacy category
        
        # Validation issues
        "validation_error": ErrorType.VALIDATION_ERROR,
        "invalid_arguments": ErrorType.VALIDATION_ERROR,
        
        # Rate limiting
        "rate_limited": ErrorType.RATE_LIMIT,
        
        # Timeout
        "timeout": ErrorType.TIMEOUT,
        
        # Internal errors
        "internal_error": ErrorType.TOOL_FAILURE,
    }
    
    return category_mapping.get(error_category)


def classify_error_from_message(error_message: str, http_status: Optional[int] = None, error_category: Optional[str] = None) -> ErrorType:
    """
    Classify error type from error message, HTTP status, and optional category.
    
    Task B2: Prefers structured error_category when available.
    
    Args:
        error_message: Error message string
        http_status: Optional HTTP status code
        error_category: Optional structured error category (Task B2)
        
    Returns:
        Appropriate ErrorType
    """
    # Task B2: Prefer structured error category if available
    if error_category:
        category_type = classify_error_from_category(error_category, http_status)
        if category_type:
            return category_type
    
    # Check HTTP status if available
    if http_status:
        return classify_error_from_http_status(http_status)
    
    # Parse error message for classification hints
    msg_lower = error_message.lower()
    
    # =========================================================================
    # AUTH ERRORS - check BEFORE infrastructure to avoid misclassification
    # e.g., "Upstream service error: API returned 401" should be AUTH_FAILURE, not RESOURCE_EXHAUSTED
    # =========================================================================
    if any(term in msg_lower for term in [
        "unauthorized", "authentication", "401", "403", 
        "forbidden", "invalid token", "expired token",
        "invalid api key", "missing credentials", "not authenticated"
    ]):
        return ErrorType.AUTH_FAILURE
    
    # =========================================================================
    # INFRASTRUCTURE/CONTAINER ERRORS - classify as TOOL_FAILURE or RESOURCE_EXHAUSTED
    # These are NOT "tool not found" - the tool exists but its backend is unavailable
    # =========================================================================
    infra_error_patterns = [
        "no such container",
        "container unavailable",
        "cannot connect to docker daemon",
        "docker exec",
        "container not running",
        "error response from daemon",
        "is not running",
        "oci runtime exec failed",
        "upstream service unavailable",
        "backend unavailable",
        "executor backend",
        "connection refused",
        "service temporarily unavailable",
    ]
    if any(pattern in msg_lower for pattern in infra_error_patterns):
        # Container/infra issues are resource failures, not missing tools
        return ErrorType.RESOURCE_EXHAUSTED
    
    # Validation errors
    if any(term in msg_lower for term in [
        "validation", "invalid", "schema", "400", "422",
        "missing required", "type error", "format error",
        "undefined index", "notice: undefined"  # PHP validation errors
    ]):
        return ErrorType.VALIDATION_ERROR
    
    # Tool not found - ONLY for actual tool lookup failures
    # Be specific to avoid catching container errors
    tool_not_found_patterns = [
        "tool not found",
        "not found on any mcp server",
        "unknown tool name",
        "unknown tool:",
        "no tool named",
    ]
    if any(pattern in msg_lower for pattern in tool_not_found_patterns):
        return ErrorType.TOOL_NOT_FOUND
    
    # 404 in message but NOT container-related should be TOOL_NOT_FOUND
    if "404" in msg_lower and not any(p in msg_lower for p in ["container", "docker", "upstream"]):
        return ErrorType.TOOL_NOT_FOUND
    
    # Rate limiting
    if any(term in msg_lower for term in [
        "rate limit", "too many requests", "429", "throttl"
    ]):
        return ErrorType.RATE_LIMIT
    
    # Timeout
    if any(term in msg_lower for term in [
        "timeout", "timed out", "504"
    ]):
        return ErrorType.TIMEOUT
    
    # Default to generic tool failure (retryable)
    return ErrorType.TOOL_FAILURE


def is_error_retryable(error_type: ErrorType) -> bool:
    """Check if an error type is retryable."""
    return error_type not in NON_RETRYABLE_ERRORS


def classify_from_mcp_result(
    result: "MCPToolResult",  # Forward reference to avoid circular import
) -> ErrorType:
    """
    Classify error from MCPToolResult using all structured fields.
    
    Task C2: Use structured fields over string parsing.
    
    Priority:
    1. terminal_hint (if True, return non-retryable immediately)
    2. error_category (most specific classification)
    3. upstream_status (actual service response)
    4. http_status (MCP layer status)
    5. error message parsing (fallback)
    
    Args:
        result: MCPToolResult with error information
        
    Returns:
        Classified ErrorType
    """
    if result.success:
        return ErrorType.TOOL_FAILURE  # Should not classify success as error
    
    # Priority 1: Honor terminal_hint from upstream
    # P1 fix: If server explicitly marks as terminal, don't retry
    if getattr(result, 'terminal_hint', False):
        # Try to get a more specific classification, but MUST be non-retryable
        if result.error_category:
            category_type = classify_error_from_category(result.error_category, result.http_status)
            if category_type and category_type not in NON_RETRYABLE_ERRORS:
                # P1 fix round 3: Category would be retryable, but terminal_hint overrides
                logger.info(
                    "MCP result has terminal_hint=True but category is retryable, forcing non-retryable",
                    extra={
                        "error": result.error,
                        "error_category": result.error_category,
                        "original_type": category_type.value,
                    },
                )
                return ErrorType.CONTRACT_ERROR
            elif category_type:
                # Category is already non-retryable, use it for specificity
                return category_type
        # Default to CONTRACT_ERROR (non-retryable) when terminal but no specific category
        logger.info(
            "MCP result has terminal_hint=True, treating as non-retryable",
            extra={"error": result.error, "error_category": result.error_category},
        )
        return ErrorType.CONTRACT_ERROR
    
    # Priority 2: Structured error category
    if result.error_category:
        category_type = classify_error_from_category(result.error_category, result.http_status)
        if category_type:
            return category_type
    
    # Priority 3: Upstream status (actual service response)
    if result.upstream_status:
        return classify_error_from_http_status(result.upstream_status)
    
    # Priority 4: HTTP status (MCP layer)
    if result.http_status:
        return classify_error_from_http_status(result.http_status)
    
    # Priority 5: Parse error message (fallback)
    return classify_error_from_message(
        result.error or "",
        result.http_status,
        result.error_category,
    )


class AgentErrorHandler:
    """Handles errors during agent execution with deterministic recovery."""

    def __init__(
        self,
        max_retries: int = 3,
        strict_terminal: bool = STRICT_TOOL_FAILURE_TERMINAL,
    ):
        """
        Initialize error handler.

        Args:
            max_retries: Maximum number of retries for transient failures
            strict_terminal: If True, exhausted retries with no fallback => ABORT
        """
        self.max_retries = max_retries
        self.strict_terminal = strict_terminal

    def classify_error(
        self,
        error_message: str,
        http_status: Optional[int] = None,
        error_category: Optional[str] = None,
    ) -> ErrorType:
        """
        Classify an error into an ErrorType.
        
        Task B2: Now accepts structured error_category for precise classification.
        
        Args:
            error_message: The error message
            http_status: Optional HTTP status code
            error_category: Optional structured error category from MCPToolResult
            
        Returns:
            Classified ErrorType
        """
        return classify_error_from_message(error_message, http_status, error_category)
    
    def classify_from_result(self, result: "MCPToolResult") -> ErrorType:
        """
        Classify error from MCPToolResult using all available fields.
        
        Task C2: Preferred method when MCPToolResult is available.
        Uses structured fields over string parsing.
        
        Args:
            result: MCPToolResult from tool execution
            
        Returns:
            Classified ErrorType
        """
        return classify_from_mcp_result(result)
    
    def is_terminal_from_result(self, result: "MCPToolResult") -> bool:
        """
        Check if error is terminal using MCPToolResult's structured fields.
        
        Task C2: Use terminal_hint for definitive terminal errors.
        
        Args:
            result: MCPToolResult from tool execution
            
        Returns:
            True if error should terminate workflow
        """
        # Use the result's built-in method which checks terminal_hint
        return result.is_terminal_error()

    def decide_recovery(self, context: ErrorContext) -> ErrorRecoveryAction:
        """
        Decide how to recover from an error.

        Args:
            context: Error context with type, step, tool info

        Returns:
            Recovery action to take
        """
        # =====================================================================
        # NON-RETRYABLE ERRORS - Fast fail immediately
        # =====================================================================
        
        # Auth failure - requires credential intervention
        if context.error_type == ErrorType.AUTH_FAILURE:
            remediation = self._build_auth_remediation_prompt(context)
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ASK_USER,
                reason="Authentication/authorization failed. User action required.",
                remediation_prompt=remediation,
                terminal=True,
            )
        
        # RBAC denial - policy issue, not credentials (different remediation)
        if context.error_type == ErrorType.RBAC_DENIED:
            remediation = self._build_rbac_remediation_prompt(context)
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ASK_USER,
                reason="Role policy denies access to this tool.",
                remediation_prompt=remediation,
                terminal=True,
            )
        
        # Catalog stale - run catalog expired, terminal signal
        if context.error_type == ErrorType.CATALOG_STALE:
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ABORT,
                reason="Tool catalog expired during run. Please retry the operation.",
                terminal=True,
            )
        
        # Validation error - bad request, won't succeed on retry
        if context.error_type == ErrorType.VALIDATION_ERROR:
            remediation = self._build_validation_remediation_prompt(context)
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ASK_USER,
                reason="Tool input validation failed. User clarification required.",
                remediation_prompt=remediation,
                terminal=True,
            )
        
        # Tool not found - won't magically appear
        if context.error_type == ErrorType.TOOL_NOT_FOUND:
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ABORT,
                reason=f"Tool '{context.tool_name}' not found. Cannot proceed.",
                terminal=True,
            )
        
        # Contract error - tool response doesn't match expected schema
        if context.error_type == ErrorType.CONTRACT_ERROR:
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ABORT,
                reason="Tool response doesn't match expected contract.",
                terminal=True,
            )
        
        # Loop detected - abort immediately
        if context.error_type == ErrorType.LOOP_DETECTED:
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ABORT,
                reason="Agent loop detected, stopping execution.",
                terminal=True,
            )
        
        # =====================================================================
        # RETRYABLE ERRORS - With budget enforcement
        # =====================================================================
        
        # Tool failure - retry with exponential backoff
        if context.error_type == ErrorType.TOOL_FAILURE:
            return self._handle_tool_failure(context)
        
        # Max retries exhausted - terminal
        if context.error_type == ErrorType.MAX_RETRIES_EXHAUSTED:
            return self._handle_exhausted_retries(context)

        # Malformed output - retry with clarification
        if context.error_type == ErrorType.MALFORMED_OUTPUT:
            if context.retry_count < 2:
                return ErrorRecoveryAction(
                    strategy=ErrorRecoveryStrategy.RETRY,
                    reason="Malformed output, retrying with clarified prompt",
                    retry_delay_seconds=1.0,
                )
            else:
                return ErrorRecoveryAction(
                    strategy=ErrorRecoveryStrategy.ABORT,
                    reason="Persistent malformed output, aborting",
                    terminal=True,
                )

        # Low confidence - ask user for guidance
        if context.error_type == ErrorType.LOW_CONFIDENCE:
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ASK_USER,
                reason="Low confidence in action, requesting user guidance",
                remediation_prompt="The agent is uncertain about this action. Please confirm or provide guidance.",
            )

        # Timeout - abort
        if context.error_type == ErrorType.TIMEOUT:
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ABORT,
                reason="Execution timeout, stopping workflow",
                terminal=True,
            )

        # Rate limit - retry with longer backoff
        if context.error_type == ErrorType.RATE_LIMIT:
            if context.retry_count < self.max_retries:
                return ErrorRecoveryAction(
                    strategy=ErrorRecoveryStrategy.RETRY,
                    reason="Rate limit hit, retrying with backoff",
                    retry_delay_seconds=60.0,  # Wait 1 minute
                )
            else:
                return ErrorRecoveryAction(
                    strategy=ErrorRecoveryStrategy.ASK_USER,
                    reason="Rate limit persists after retries. Please wait and try again.",
                    terminal=True,
                )

        # Resource exhausted - infrastructure/container issues
        if context.error_type == ErrorType.RESOURCE_EXHAUSTED:
            remediation = self._build_infra_remediation_prompt(context)
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ASK_USER,
                reason="Infrastructure dependency unavailable. Admin action required.",
                remediation_prompt=remediation,
                terminal=True,
            )

        # Default: abort
        return ErrorRecoveryAction(
            strategy=ErrorRecoveryStrategy.ABORT,
            reason=f"Unhandled error type: {context.error_type}",
            terminal=True,
        )

    def _handle_tool_failure(self, context: ErrorContext) -> ErrorRecoveryAction:
        """Handle generic/transient tool failure with retry budget."""
        # Check retry budget
        if context.retry_count < min(self.max_retries, context.attempt_budget):
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.RETRY,
                reason=f"Transient tool failure, retrying (attempt {context.retry_count + 1}/{context.attempt_budget})",
                retry_delay_seconds=2.0 ** context.retry_count,  # Exponential backoff
            )
        
        # Exhausted retries
        return self._handle_exhausted_retries(context)
    
    def _handle_exhausted_retries(self, context: ErrorContext) -> ErrorRecoveryAction:
        """Handle exhausted retry budget - ABORT or FALLBACK, never SKIP."""
        # Check for fallback tool
        fallback = self._find_fallback_tool(context.tool_name)
        if fallback:
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.FALLBACK,
                reason=f"Max retries exceeded, using fallback: {fallback}",
                fallback_tool=fallback,
            )
        
        # No fallback - ABORT (or ASK_USER in non-strict mode)
        if self.strict_terminal:
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ABORT,
                reason=f"Tool '{context.tool_name}' failed after {context.retry_count} attempts with no fallback. Aborting.",
                terminal=True,
            )
        else:
            # Non-strict mode: ask user what to do
            return ErrorRecoveryAction(
                strategy=ErrorRecoveryStrategy.ASK_USER,
                reason=f"Tool '{context.tool_name}' failed repeatedly. How would you like to proceed?",
                remediation_prompt=(
                    f"The tool '{context.tool_name}' failed after {context.retry_count} attempts.\n"
                    f"Last error: {context.error_message}\n\n"
                    "Options:\n"
                    "1. Retry with different parameters\n"
                    "2. Skip this step and continue\n"
                    "3. Abort the workflow"
                ),
            )
    
    def _build_auth_remediation_prompt(self, context: ErrorContext) -> str:
        """Build a structured remediation prompt for auth failures."""
        tool_name = context.tool_name or "unknown"
        
        # Check for specific auth error hints
        msg_lower = context.error_message.lower()
        
        if "expired" in msg_lower:
            action = "Your authentication token has expired. Please re-authenticate."
        elif "invalid" in msg_lower:
            action = "The authentication credentials are invalid. Please check your API key or token."
        elif "403" in context.error_message or "forbidden" in msg_lower:
            action = "You don't have permission to perform this action. Check your access scope."
        else:
            action = "Authentication failed. Please verify your credentials."
        
        return (
            f"Authentication error for tool '{tool_name}':\n"
            f"{context.error_message}\n\n"
            f"Recommended action: {action}\n\n"
            "To resolve:\n"
            "1. Check if your API key/token is valid and not expired\n"
            "2. Verify you have the required permissions/scopes\n"
            "3. Try refreshing your credentials\n"
            "4. Contact your administrator if the issue persists"
        )

    def _build_rbac_remediation_prompt(self, context: ErrorContext) -> str:
        """Build a structured remediation prompt for RBAC/policy denial.
        
        Refactor: Distinct from auth failure - this is role policy, not credentials.
        """
        tool_name = context.tool_name or "unknown"
        error_category = context.metadata.get("error_category", "rbac_denied") if context.metadata else "rbac_denied"
        
        return (
            f"Access to tool '{tool_name}' is not allowed for your current role.\n\n"
            f"Error: {context.error_message}\n\n"
            "This is a role-based access control (RBAC) restriction, not a credential issue.\n\n"
            "To resolve:\n"
            "1. Contact your administrator to request access to this tool\n"
            "2. Use an alternative tool that your role has access to\n"
            "3. If you believe this is an error, report the issue to support"
        )

    def _build_validation_remediation_prompt(self, context: ErrorContext) -> str:
        """Build a structured remediation prompt for validation failures."""
        tool_name = context.tool_name or "the requested tool"
        raw_message = context.error_message or "Validation failed."
        message = raw_message.strip()

        # Extract likely field names from common validator error formats.
        fields: list[str] = []
        for pattern in [
            r"at ['\"]([a-zA-Z0-9_]+)['\"]",
            r"field ['\"]([a-zA-Z0-9_]+)['\"]",
            r"parameter ['\"]([a-zA-Z0-9_]+)['\"]",
        ]:
            for match in re.findall(pattern, message):
                if match not in fields:
                    fields.append(match)

        # Include current attempted args when available for easier correction.
        tool_args = context.metadata.get("tool_args") if isinstance(context.metadata, dict) else None
        args_summary = ""
        if isinstance(tool_args, dict) and tool_args:
            try:
                args_summary = json.dumps(tool_args, ensure_ascii=True)
            except Exception:
                args_summary = str(tool_args)
            if len(args_summary) > 400:
                args_summary = args_summary[:400] + "..."

        field_guidance = (
            f"Please provide corrected values for: {', '.join(fields)}."
            if fields else
            "Please provide corrected values for the invalid or missing fields."
        )

        prompt = (
            f"I couldn't execute '{tool_name}' because the tool input failed validation.\n"
            f"Validation error: {message}\n\n"
            f"{field_guidance}\n"
            "Reply with the corrected values only, and I will retry."
        )

        if args_summary:
            prompt += f"\n\nCurrent values attempted: {args_summary}"

        return prompt

    def _build_infra_remediation_prompt(self, context: ErrorContext) -> str:
        """Build a structured remediation prompt for infrastructure/container failures."""
        tool_name = context.tool_name or "the requested tool"
        raw_message = context.error_message or "Infrastructure dependency unavailable."
        msg_lower = raw_message.lower()
        
        # Detect specific infrastructure issues
        if "no such container" in msg_lower or "container not running" in msg_lower:
            issue = "Required container is not running"
            remediation = (
                "1. Start the required containers: `docker-compose up -d`\n"
                "2. Verify the container is healthy: `docker ps`\n"
                "3. Check container logs for startup errors: `docker logs <container-name>`"
            )
        elif "docker daemon" in msg_lower:
            issue = "Docker daemon is not accessible"
            remediation = (
                "1. Start Docker Desktop or the Docker daemon\n"
                "2. Verify Docker is running: `docker info`\n"
                "3. Check Docker socket permissions"
            )
        elif "connection refused" in msg_lower:
            issue = "Backend service is not reachable"
            remediation = (
                "1. Check if the required service is running\n"
                "2. Verify network connectivity to the service\n"
                "3. Check firewall rules and port availability"
            )
        elif "executor" in msg_lower:
            issue = "Gateway executor backend is misconfigured"
            remediation = (
                "1. Check gateway executor configuration (GATEWAY_ENV)\n"
                "2. Verify the executor backend is available (docker/k8s/http)\n"
                "3. Review gateway logs for configuration errors"
            )
        else:
            issue = "Infrastructure dependency is unavailable"
            remediation = (
                "1. Check that all required services are running\n"
                "2. Verify gateway health: curl http://localhost:8090/health\n"
                "3. Review backend and gateway logs for errors"
            )
        
        return (
            f"Infrastructure error for tool '{tool_name}':\n"
            f"{raw_message}\n\n"
            f"Issue: {issue}\n\n"
            f"To resolve:\n{remediation}\n\n"
            "This is an infrastructure issue, not a problem with your request. "
            "Please contact your administrator or DevOps team if you cannot resolve it."
        )

    def _find_fallback_tool(self, failed_tool: Optional[str]) -> Optional[str]:
        """
        Find fallback tool for a failed tool.

        Args:
            failed_tool: Name of tool that failed

        Returns:
            Name of fallback tool or None

        Note: Fallback mappings should only map to tools with compatible
        argument schemas. Never map to execute_bash as this could allow
        shell injection with user-controlled arguments.
        """
        # Define safe fallback mappings (same argument schema required)
        # WARNING: Do NOT add execute_bash as fallback - security risk
        fallbacks: dict = {
            # Add safe fallback mappings here, e.g.:
            # "primary_db_query": "backup_db_query",
        }
        return fallbacks.get(failed_tool)

    def parse_confidence(self, llm_response: str) -> float:
        """
        Parse confidence level from LLM response.

        Args:
            llm_response: Text response from LLM

        Returns:
            Confidence score 0.0-1.0
        """
        # Look for confidence indicators
        # Order matters: check longer/more specific keywords first to avoid substring matches
        # e.g., "uncertain" should be checked before "certain"
        confidence_keywords = {
            "uncertain": 0.3,
            "confident": 0.8,
            "certain": 0.9,
            "probably": 0.6,
            "likely": 0.7,
            "unsure": 0.4,
            "maybe": 0.5,
            "guess": 0.2,
        }

        response_lower = llm_response.lower()
        for keyword, score in confidence_keywords.items():
            if keyword in response_lower:
                return score

        # Default: medium confidence
        return 0.7
